export interface IProduct {
   ProductID: number;
   ProductName: string;
}

